import AsyncStorage from '@react-native-async-storage/async-storage';
const KEY = '@forgemtg_collection_v1';

export async function loadCollection() {
  const raw = await AsyncStorage.getItem(KEY);
  if (!raw) return [];
  try { return JSON.parse(raw); } catch(e) { return []; }
}

export async function saveCollection(list) {
  await AsyncStorage.setItem(KEY, JSON.stringify(list));
}

export async function addOrIncrement(card) {
  const list = await loadCollection();
  const idx = list.findIndex(c => (c.id && card.id && c.id === card.id) || c.name === card.name);
  if (idx >= 0) {
    list[idx].count = (list[idx].count || 1) + 1;
  } else {
    const entry = { ...card, count: 1 };
    list.push(entry);
  }
  await saveCollection(list);
  return list;
}

export async function decrementOrRemove(cardId) {
  const list = await loadCollection();
  const idx = list.findIndex(c => c.id === cardId);
  if (idx >= 0) {
    list[idx].count = (list[idx].count || 1) - 1;
    if (list[idx].count <= 0) list.splice(idx,1);
    await saveCollection(list);
  }
  return list;
}

export async function clearAll() {
  await saveCollection([]);
  return [];
}
