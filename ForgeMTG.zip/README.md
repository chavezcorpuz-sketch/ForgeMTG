# ForgeMTG

A GitHub-ready prototype for **ForgeMTG**: a mobile-first Expo app + Node server.
The app supports card scanning (photo -> OCR -> Scryfall), collection management,
and EDH/Commander deck generation using EDHREC-style heuristics.

## Layout
- `client/` — Expo React Native app (mobile)
- `server/` — Node/Express server for OCR + archetype analysis

## Quickstart (local)
1. Start server (in one terminal):
   ```bash
   cd server
   npm install
   # set GOOGLE_APPLICATION_CREDENTIALS to your Google Cloud Vision JSON creds
   export GOOGLE_APPLICATION_CREDENTIALS="/path/to/key.json"
   npm start
   ```

2. Start client (in another terminal):
   ```bash
   cd client
   npm install
   # edit SERVER_URL in client/components/Scanner.js and DeckBuilder.js to point to your server (e.g., http://192.168.1.100:3333)
   npm start
   ```

3. Open the Expo app on your phone (Expo Go) and scan the QR code.

## Notes
- Replace `SERVER_URL` in the client with your server IP when testing on a physical device.
- The server expects `GOOGLE_APPLICATION_CREDENTIALS` environment variable for Google Vision API.
